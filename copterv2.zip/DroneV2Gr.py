import sys
from PyQt4 import QtCore
from PyQt4 import QtGui
import CopterGUIv2
from time import sleep

import serial

ser = serial.Serial('/dev/ttyACM0', 115200)



throttle = 0
Yaw = 128
Pitch = 125
Roll = 132


class MainG (QtGui.QMainWindow ,CopterGUIv2.Ui_MainWindow):



    def __init__(self, parent = None ):
        super(MainG, self).__init__(parent)
        self.setupUi(self)

        ##ControlledFlight##
        self.ThrottleHIGH.pressed.connect(self.ThrottleUP)
        self.ThrottleLOW.pressed.connect(self.ThrottleDOWN)
        self.YawHigh.pressed.connect(self.YawUP)
        self.YawLOW.pressed.connect(self.YawDOWN)
        self.YawReset.pressed.connect(self.Yawreset)

        self.PitchHIGH.pressed.connect(self.PitchUP)
        self.PitchLOW.pressed.connect(self.PitchDOWN)
        self.RollHIGH.pressed.connect(self.RollUP)
        self.RollLOW.pressed.connect(self.RollDOWN)
        self.PitchRollReset.pressed.connect(self.PitchRollreset)
        ##Binding##
        self.BindBUtton.pressed.connect(self.Binding)





    def RadioWrite(self,com,Value):

        if self.Copter1.isChecked():
            ser.write('01'+com+str(hex(Value))+' ')
        if self.Copter2.isChecked():
            ser.write('02'+com+str(hex(Value))+' ')
        if self.Copter3.isChecked():
            ser.write('03'+com+str(hex(Value))+' ')
        if self.Copter4.isChecked():
            ser.write('04'+com+str(hex(Value))+' ')
        if self.Copter5.isChecked():
            ser.write('05'+com+str(hex(Value))+' ')
        if self.Copter6.isChecked():
            ser.write('06'+com+str(hex(Value))+' ')

        sleep(0.4)




##ControlledFlight##
    def ThrottleUP(self):
        global throttle
        throttle = throttle + 1
        self.Thrust.display(throttle)
        self.RadioWrite('02', throttle)





    def ThrottleDOWN(self):
        global throttle
        throttle = throttle -1
        self.Thrust.display(throttle)

        self.RadioWrite('02', throttle)



    def YawUP(self):
        global Yaw
        Yaw = Yaw +1
        self.Yaw.display(Yaw)
        self.RadioWrite('03', Yaw)


    def YawDOWN(self):
        global Yaw
        Yaw = Yaw - 1
        self.Yaw.display(Yaw)
        self.RadioWrite('03', Yaw)


    def Yawreset(self):
        global Yaw
        Yaw = 52
        self.Yaw.display(Yaw)
        self.RadioWrite('03', Yaw)

    def PitchUP(self):
        global Pitch
        Pitch = Pitch+1
        self.Pitch.display(Pitch)
        self.RadioWrite('05', Pitch)

    def PitchDOWN(self):
        global Pitch
        Pitch = Pitch-1
        self.Pitch.display(Pitch)
        self.RadioWrite('05', Pitch)

    def RollUP(self):
        global Roll
        Roll = Roll + 1
        self.ROll.display(Roll)
        self.RadioWrite('04', Roll)

    def RollDOWN(self):
        global Roll
        Roll = Roll - 1
        self.ROll.display(Roll)
        self.RadioWrite('04', Roll)

    def PitchRollreset(self):

        global Pitch,Roll

        Roll = 132
        Pitch = 125
        self.ROll.display(Roll)
        self.Pitch.display(Pitch)
        self.RadioWrite('04', Roll)
        self.RadioWrite('05', Pitch)

##Binding##

    def Binding(self):
        ser.write('000101 ')








a =QtGui.QApplication(sys.argv)

app = MainG()
app.show()

a.exec_()
